import RouterAppProvider from "./routers/RouterAppProvider";

function App() {
  return <RouterAppProvider />;
}

export default App;
