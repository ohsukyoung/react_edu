const Main = () => {
  return (
    <>
      <section className="wrapper">Welcome to React Todo!</section>
    </>
  );
};
export default Main;
