import TodoApp from "./Components/TodoApp";

function App() {
  return <TodoApp />;
}

export default App;
